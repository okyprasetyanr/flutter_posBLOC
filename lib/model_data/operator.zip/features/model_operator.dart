import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_pos/function/function.dart';
import 'package:flutter_pos/request/push_data.dart';

enum RoleType { Pemilik, Kasir, Admin }

extension RoleTypeX on RoleType {
  int get id {
    switch (this) {
      case RoleType.Pemilik:
        return 0;
      case RoleType.Admin:
        return 1;
      case RoleType.Kasir:
        return 2;
    }
  }
}

RoleType fromIdRoleType(int id) {
  switch (id) {
    case 0:
      return RoleType.Pemilik;
    case 1:
      return RoleType.Admin;
    case 2:
      return RoleType.Kasir;
    default:
      return RoleType.Pemilik;
  }
}

enum Permission {
  TransactionAll,
  TransactionSell,
  TransactionBuy,
  TransactionIncome,
  TransactionExpense,
  DataAll,
  DataCustomer,
  DataSupplier,
  DataIncome,
  DataExpense,
  HistoryAll,
  HistorySell,
  HistoryBuy,
  HistoryIncome,
  HistoryExpense,
  Report,
}

class PermissionAccess {
  final Map<Permission, bool> access;

  PermissionAccess({required this.access});

  bool statusPermission(Permission permission) => access[permission] ?? false;

  factory PermissionAccess.fromJson(Map<String, dynamic> data) {
    return PermissionAccess(
      access: {
        for (final permission in Permission.values)
          permission: data[permission.name] ?? false,
      },
    );
  }

  Map<String, dynamic> toJson() {
    return {
      for (var permission in Permission.values)
        permission.name: access[permission],
    };
  }
}

class ModelOperator extends Equatable {
  final String idOperator;
  final String nameOperator;
  final String idBranchOperator;
  final int roleOperator;
  final String emailOperator;
  final String phoneOperator;
  final String passwordOperator;
  final String note;
  final String uidOwner;
  final bool statusOperator;
  final DateTime created;

  final PermissionAccess permissionAccess;

  ModelOperator({
    required this.passwordOperator,
    required this.idOperator,
    required this.nameOperator,
    required this.idBranchOperator,
    required this.roleOperator,
    required this.emailOperator,
    required this.phoneOperator,
    required this.statusOperator,
    required this.uidOwner,
    required this.created,
    required this.note,
    required this.permissionAccess,
  });

  String get getidOperator => idOperator;
  String get getnameOperator => nameOperator;
  String get getidBranchOperator => idBranchOperator;
  String get getemailOperator => emailOperator;
  String get getphoneOperator => phoneOperator;
  String get getuidOwner => uidOwner;
  String get getnote => note;
  bool get getstatusOperator => statusOperator;
  int get getroleOperator => roleOperator;
  DateTime get getcreated => created;

  ModelOperator copyWith({
    String? passwordOperator,
    String? idOperator,
    String? nameOperator,
    String? idBranchOperator,
    int? roleOperator,
    String? emailOperator,
    String? phoneOperator,
    String? note,
    String? uidOwner,
    bool? statusOperator,
    DateTime? created,
    PermissionAccess? permissionAccess,
  }) {
    return ModelOperator(
      passwordOperator: passwordOperator ?? this.passwordOperator,
      idOperator: idOperator ?? this.idOperator,
      nameOperator: nameOperator ?? this.nameOperator,
      idBranchOperator: idBranchOperator ?? this.idBranchOperator,
      roleOperator: roleOperator ?? this.roleOperator,
      emailOperator: emailOperator ?? this.emailOperator,
      phoneOperator: phoneOperator ?? this.phoneOperator,
      statusOperator: statusOperator ?? this.statusOperator,
      uidOwner: uidOwner ?? this.uidOwner,
      created: created ?? this.created,
      note: note ?? this.note,
      permissionAccess: permissionAccess ?? this.permissionAccess,
    );
  }

  Future<void> pushDataOperator() async {
    pushWorkerDataOperator(
      collection: 'operator',
      id: idOperator,
      dataOperator: {
        'pass_operator': passwordOperator,
        'id_operator': idOperator,
        'name_operator': nameOperator,
        'id_branch': idBranchOperator,
        'role_operator': roleOperator,
        'email_operator': emailOperator,
        'phone_operator': phoneOperator,
        'status_operator': statusOperator,
        'uid_owner': uidOwner,
        'created': created,
        'note': note,
        'permission': permissionAccess.toJson(),
        'uid_user': UserSession.getUidUser(),
      },
    );
  }

  factory ModelOperator.fromMap(Map<String, dynamic> data, id) {
    return ModelOperator(
      passwordOperator: data['password_operator'],
      idOperator: data['id_operator'] ?? '',
      nameOperator: data['name_operator'] ?? '',
      idBranchOperator: data['id_branch'] ?? '',
      roleOperator: data['role_operator'] ?? 0,
      emailOperator: data['email_operator'] ?? '',
      phoneOperator: data['phone_operator'] ?? '',
      statusOperator: data['status_operator'] ?? false,
      uidOwner: data['uid_owner'] ?? '',
      created: data['created'] ?? DateTime.now(),
      note: data['note'] ?? '',
      permissionAccess: PermissionAccess.fromJson(data['permission'] ?? {}),
    );
  }

  static List<ModelOperator> getDataListOperator(QuerySnapshot data) {
    return data.docs.map((map) {
      final data = map.data() as Map<String, dynamic>;
      return ModelOperator.fromMap(data, map.id);
    }).toList();
  }

  @override
  List<Object?> get props => [
    idOperator,
    passwordOperator,
    nameOperator,
    idBranchOperator,
    roleOperator,
    emailOperator,
    phoneOperator,
    statusOperator,
    uidOwner,
    created,
    note,
    permissionAccess,
  ];
}
